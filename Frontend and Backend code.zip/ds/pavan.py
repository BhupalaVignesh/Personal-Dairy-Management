import bcrypt

import os
import pickle
import bcrypt
import getpass
from cryptography.fernet import Fernet

# ========== SETUP ==========
KEY_FILE = "secret.key"
USER_FILE = "users.pkl"

# Generate encryption key if it doesn't exist
if not os.path.exists(KEY_FILE):
    with open(KEY_FILE, 'wb') as f:
        f.write(Fernet.generate_key())

with open(KEY_FILE, 'rb') as f:
    key = f.read()
fernet = Fernet(key)

# ========== USER AUTH ==========
def load_users():
    if os.path.exists(USER_FILE):
        with open(USER_FILE, 'rb') as f:
            return pickle.load(f)
    return {}

def save_users(users):
    with open(USER_FILE, 'wb') as f:
        pickle.dump(users, f)

'''def register():
    users = load_users()
    username = input("Enter new username: ").strip()
    if username in users:
        print("Username already exists.")
        return None
    password = getpass.getpass("Enter new password: ").strip()
    hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt())
    users[username] = hashed
    save_users(users)
    print("Registration successful.")
    return username
    '''
def register(username, password):
    users = load_users()
    if username in users:
        return "Username already exists"
    hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt())
    users[username] = hashed
    save_users(users)
    return "Registration successful"

'''def login():
    users = load_users()
    username = input("Enter username: ").strip()
    password = getpass.getpass("Enter password: ").strip()
    if username in users and bcrypt.checkpw(password.encode(), users[username]):
        print("Login successful.")
        return username
    print("Invalid credentials.")
    return None
    '''
def login(username, password):
    users = load_users()
    if username in users and bcrypt.checkpw(password.encode(), users[username]):
        return "Login successful"
    return "Invalid credentials"

# ========== RECORD HANDLING ==========
class Record:
    def __init__(self, time, name, place, duration, note):
        self.time = time
        self.name = name
        self.place = place
        self.duration = duration
        self.note = note

def get_filename(username):
    date = input("Enter the date of the record [yyyy-mm-dd]: ").strip()
    return f"{username}_{date}.bin"

def encrypt_data(data):
    return fernet.encrypt(pickle.dumps(data))

def decrypt_data(data):
    return pickle.loads(fernet.decrypt(data))

def add_record(username):
    os.system('cls' if os.name == 'nt' else 'clear')
    filename = get_filename(username)
    records = []
    if os.path.exists(filename):
        with open(filename, 'rb') as f:
            records = decrypt_data(f.read())

    while True:
        time = input("Enter time [hhmm]: ").strip()
        if any(r.time == time for r in records):
            print("Record already exists at this time.")
        else:
            name = input("Enter name: ").strip()
            place = input("Enter place: ").strip()
            duration = input("Enter duration: ").strip()
            note = input("Enter note: ").strip()
            record = Record(time, name, place, duration, note)
            records.append(record)
            print("Record added.")

        another = input("Add another record? (Y/N): ").strip().lower()
        if another != 'y':
            break

    with open(filename, 'wb') as f:
        f.write(encrypt_data(records))
    input("Press Enter to continue...")

def view_record(username):
    os.system('cls' if os.name == 'nt' else 'clear')
    filename = get_filename(username)
    if not os.path.exists(filename):
        print("No record exists for this date.")
        input("Press Enter to continue...")
        return

    with open(filename, 'rb') as f:
        records = decrypt_data(f.read())

    choice = input("View (1) whole day or (2) specific time? Enter choice: ").strip()
    if choice == '1':
        for r in records:
            print("\n---")
            print(f"Time: {r.time}")
            print(f"Meeting with: {r.name}")
            print(f"Meeting at: {r.place}")
            print(f"Duration: {r.duration}")
            print(f"Note: {r.note}")
    elif choice == '2':
        time = input("Enter time [hhmm]: ").strip()
        found = False
        for r in records:
            if r.time == time:
                print("\n---")
                print(f"Time: {r.time}")
                print(f"Meeting with: {r.name}")
                print(f"Meeting at: {r.place}")
                print(f"Duration: {r.duration}")
                print(f"Note: {r.note}")
                found = True
        if not found:
            print("No record found at that time.")
    input("Press Enter to continue...")

def edit_record(username):
    os.system('cls' if os.name == 'nt' else 'clear')
    filename = get_filename(username)
    if not os.path.exists(filename):
        print("No record exists for this date.")
        input("Press Enter to continue...")
        return

    with open(filename, 'rb') as f:
        records = decrypt_data(f.read())

    time = input("Enter time of the record to edit [hhmm]: ").strip()
    for r in records:
        if r.time == time:
            print("Current record:")
            print(f"1. Time: {r.time}")
            print(f"2. Meeting with: {r.name}")
            print(f"3. Meeting at: {r.place}")
            print(f"4. Duration: {r.duration}")
            print(f"5. Note: {r.note}")
            print(f"6. Edit entire record")

            option = input("Enter field to edit (1-6): ").strip()
            if option == '1':
                r.time = input("New time: ")
            elif option == '2':
                r.name = input("New name: ")
            elif option == '3':
                r.place = input("New place: ")
            elif option == '4':
                r.duration = input("New duration: ")
            elif option == '5':
                r.note = input("New note: ")
            elif option == '6':
                r.time = input("New time: ")
                r.name = input("New name: ")
                r.place = input("New place: ")
                r.duration = input("New duration: ")
                r.note = input("New note: ")
            break
    else:
        print("Record not found.")
        input("Press Enter to continue...")
        return

    with open(filename, 'wb') as f:
        f.write(encrypt_data(records))
    print("Record updated.")
    input("Press Enter to continue...")

def delete_record(username):
    os.system('cls' if os.name == 'nt' else 'clear')
    filename = get_filename(username)
    if os.path.exists(filename):
        os.remove(filename)
        print("Record deleted.")
    else:
        print("No record found.")
    input("Press Enter to continue...")

# ========== MAIN ==========
def main():
    while True:
        os.system('cls' if os.name == 'nt' else 'clear')
        print("\n--- Welcome to Secure Personal Diary ---")
        print("1. Login")
        print("2. Register")
        print("3. Exit")
        choice = input("Enter choice: ").strip()
        if choice == '1':
            user = login()
            if user:
                user_menu(user)
        elif choice == '2':
            user = register()
            if user:
                user_menu(user)
        elif choice == '3':
            print("Thankyou..")
            break
        else:
            print("Invalid choice.")
            input("Press Enter to try again...")

def user_menu(user):
    while True:
        os.system('cls' if os.name == 'nt' else 'clear')
        print(f"\n******** Welcome, {user}! ********")
        print("1. Add Record")
        print("2. View Record")
        print("3. Edit Record")
        print("4. Delete Record")
        print("5. Logout")
        choice = input("Enter your choice: ").strip()

        if choice == '1':
            add_record(user)
        elif choice == '2':
            view_record(user)
        elif choice == '3':
            edit_record(user)
        elif choice == '4':
            delete_record(user)
        elif choice == '5':
            print("Logging out...")
            break
        else:
            print("Invalid choice!")
            input("Press Enter to try again...")

if __name__ == "__main__":
    main()

# app.py
from flask import Flask, render_template, request, redirect, session, url_for
import os
import pickle
from pavan import register, login, decrypt_data, encrypt_data, Record

app = Flask(__name__)
app.secret_key = 'your_secret_key'

@app.route('/')
def home():
    return render_template('dairy.html')

@app.route('/login', methods=['POST'])
def login_user():
    username = request.form['username']
    password = request.form['password']
    result = login(username, password)
    if result == "Login successful":
        session['username'] = username
        return redirect('/dashboard')
    return 'Invalid credentials'

@app.route('/register', methods=['POST'])
def register_user():
    username = request.form['username']
    password = request.form['password']
    result = register(username, password)
    if result == "Registration successful":
        return 'Registration successful'
    return 'Username already exists'

@app.route('/dashboard')
def dashboard():
    if 'username' in session:
        return render_template('dashboard.html', username=session['username'])
    return redirect('/')

@app.route('/add', methods=['GET', 'POST'])
def add():
    if 'username' not in session:
        return redirect('/')

    if request.method == 'POST':
        date = request.form.get('date')
        if not date:
            return "⚠️ Date is required!", 400

        filename = f"{session['username']}_{date}.bin"
        records = []
        if os.path.exists(filename):
            with open(filename, 'rb') as f:
                records = decrypt_data(f.read())

        record = Record(
            time=request.form.get('time'),
            name=request.form.get('name'),
            place=request.form.get('place'),
            duration=request.form.get('duration'),
            note=request.form.get('note')
        )

        records.append(record)
        with open(filename, 'wb') as f:
            f.write(encrypt_data(records))

        return '✅ Record added successfully!'

    return render_template('add.html')

@app.route('/view', methods=['GET', 'POST'])
def view():
    if 'username' not in session:
        return redirect('/')

    if request.method == 'POST':
        date = request.form.get('date')
        view_type = request.form.get('view_type')
        time_filter = request.form.get('time')

        filename = f"{session['username']}_{date}.bin"
        if not os.path.exists(filename):
            return render_template('view.html', message="No records found.", records=None, date=date)

        with open(filename, 'rb') as f:
            records = decrypt_data(f.read())

        if view_type == "specific" and time_filter:
            records = [r for r in records if r.time == time_filter]

        return render_template('view.html', records=records, date=date)

    return render_template('view.html')

@app.route('/edit', methods=['GET', 'POST'])
def edit():
    if 'username' not in session:
        return redirect('/')

    if request.method == 'POST':
        date = request.form.get('date')
        time = request.form.get('time')
        filename = f"{session['username']}_{date}.bin"

        if not os.path.exists(filename):
            return render_template('edit.html', message="Record not found.")

        with open(filename, 'rb') as f:
            records = decrypt_data(f.read())

        found = False
        for record in records:
            if record.time == time:
                record.name = request.form.get('name')
                record.place = request.form.get('place')
                record.duration = request.form.get('duration')
                record.note = request.form.get('note')
                found = True
                break

        if not found:
            return render_template('edit.html', message="Record not found.")

        with open(filename, 'wb') as f:
            f.write(encrypt_data(records))

        return redirect('/view')

    return render_template('edit.html')

@app.route('/delete', methods=['GET', 'POST'])
def delete():
    if 'username' not in session:
        return redirect('/')

    if request.method == 'POST':
        date = request.form.get('date')
        time = request.form.get('time')
        filename = f"{session['username']}_{date}.bin"

        if not os.path.exists(filename):
            return render_template('delete.html', message="Record not found.")

        with open(filename, 'rb') as f:
            records = decrypt_data(f.read())

        new_records = [r for r in records if r.time != time]

        if len(new_records) == len(records):
            return render_template('delete.html', message="Record not found.")

        with open(filename, 'wb') as f:
            f.write(encrypt_data(new_records))

        return redirect('/view')

    return render_template('delete.html')



@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)
